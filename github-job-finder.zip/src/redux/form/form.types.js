const formActionsTypes = {
  SET_FORM_DATA: "SET_FORM_DATA",
  CLEAR_FORM_DATA: "CLEAR_FORM_DATA",
};

export default formActionsTypes;
